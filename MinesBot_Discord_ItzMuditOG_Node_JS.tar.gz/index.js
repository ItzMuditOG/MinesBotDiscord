const { Client, GatewayIntentBits, EmbedBuilder, ButtonBuilder, ActionRowBuilder, 
        ButtonStyle, SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

// Bot configuration from environment variables
const TOKEN = process.env.BOT_TOKEN;
const ADMIN_ID = process.env.ADMIN_ID;
const DATA_FILE = path.join(__dirname, 'userdata.json');

// Game configuration
const BASE_HOUSE_EDGE = 0.05; // 5% house edge
const DEFAULT_STARTING_BALANCE = 1000;
const MAX_MINES = 8; // reduced from 24
const GRID_SIZE = 9; // 3x3 grid
const DAILY_BONUS = 100;

// Hidden admin commands prefix (only admins will know this)
const ADMIN_PREFIX = '!admin';

// Initialize client with required intents
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

// Store active games and user data
const activeGames = new Map();
let userData = {};

// Store rigged game settings (hidden from users)
const riggedUsers = new Map();

// Load user data from file
function loadUserData() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            const data = fs.readFileSync(DATA_FILE, 'utf8');
            userData = JSON.parse(data);
            console.log('User data loaded successfully');
        } else {
            console.log('No existing user data found, starting fresh');
            userData = {};
        }
    } catch (err) {
        console.error('Error loading user data:', err);
        userData = {};
    }
}

// Save user data to file
function saveUserData() {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(userData, null, 2));
    } catch (err) {
        console.error('Error saving user data:', err);
    }
}

// Generate a new mines game
function generateGame(mineCount) {
    // Generate mine positions
    const mines = new Set();
    while (mines.size < mineCount) {
        const position = Math.floor(Math.random() * GRID_SIZE);
        mines.add(position);
    }

    return {
        mines: mines,
        revealed: new Set(),
        gameOver: false,
        wonAmount: 0,
        currentMultiplier: 1.0
    };
}

// Generate a rigged game where player will win or lose (hidden function)
function generateRiggedGame(mineCount, shouldWin) {
    const mines = new Set();
    
    if (shouldWin) {
        // Place mines in bottom row for easy avoidance
        for (let i = GRID_SIZE - 3; i < GRID_SIZE && mines.size < mineCount; i++) {
            mines.add(i);
        }
        // Fill remaining mines if needed
        while (mines.size < mineCount) {
            const position = GRID_SIZE - Math.floor(Math.random() * 3) - 1;
            mines.add(position);
        }
    } else {
        // Place mines in common first-click positions (center and corners)
        const commonPositions = [0, 2, 4, 6, 8];
        for (let i = 0; i < commonPositions.length && mines.size < mineCount; i++) {
            mines.add(commonPositions[i]);
        }
        // Fill remaining mines randomly
        while (mines.size < mineCount) {
            const position = Math.floor(Math.random() * GRID_SIZE);
            if (!mines.has(position)) {
                mines.add(position);
            }
        }
    }

    return {
        mines: mines,
        revealed: new Set(),
        gameOver: false,
        wonAmount: 0,
        currentMultiplier: 1.0
    };
}

// Calculate win multiplier based on mines and tiles revealed
function calculateMultiplier(mineCount, revealedCount) {
    // Base formula with house edge applied
    const fairMultiplier = Math.pow(GRID_SIZE / (GRID_SIZE - mineCount), revealedCount);
    return fairMultiplier * (1 - BASE_HOUSE_EDGE);
}

// Generate game embed
function createGameEmbed(username, game, betAmount) {
    const embed = new EmbedBuilder()
        .setTitle('💣 Mines Game')
        .setColor('#FF9900')
        .setDescription(`**Bet Amount:** ${betAmount} coins\n**Mines:** ${game.mines.size}\n**Current Multiplier:** ${game.currentMultiplier.toFixed(2)}x\n**Potential Win:** ${Math.floor(betAmount * game.currentMultiplier)} coins`)
        .setFooter({ text: `Player: ${username} | Revealed: ${game.revealed.size} tiles` });
    
    return embed;
}

// Create game buttons - 3x3 grid
function createGameButtons(game) {
    const rows = [];
    
    // Create 3 rows of 3 buttons each (3x3 grid)
    for (let r = 0; r < 3; r++) {
        const actionRow = new ActionRowBuilder();
        
        for (let c = 0; c < 3; c++) {
            const position = r * 3 + c;
            const isRevealed = game.revealed.has(position);
            const isMine = game.mines.has(position);
            
            let button;
            
            if (isRevealed) {
                if (isMine) {
                    button = new ButtonBuilder()
                        .setCustomId(`tile_${position}`)
                        .setLabel('💣')
                        .setStyle(ButtonStyle.Danger)
                        .setDisabled(true);
                } else {
                    button = new ButtonBuilder()
                        .setCustomId(`tile_${position}`)
                        .setLabel('💎')
                        .setStyle(ButtonStyle.Success)
                        .setDisabled(true);
                }
            } else {
                button = new ButtonBuilder()
                    .setCustomId(`tile_${position}`)
                    .setLabel('?')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(game.gameOver);
            }
            
            actionRow.addComponents(button);
        }
        
        rows.push(actionRow);
    }
    
    // Add cashout button in its own action row (4th row)
    const actionRow = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('cashout')
                .setLabel('💰 CASHOUT')
                .setStyle(ButtonStyle.Primary)
                .setDisabled(game.gameOver || game.revealed.size === 0)
        );
    
    rows.push(actionRow);
    return rows;
}

// Initialize slash commands
client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}`);
    
    // Load user data
    loadUserData();
    
    try {
        console.log('Started refreshing application (/) commands.');
        
        // Only register visible commands - no /rig command
        await client.application.commands.set([
            new SlashCommandBuilder()
                .setName('play')
                .setDescription('Start a new mines game')
                .addIntegerOption(option => 
                    option.setName('bet')
                        .setDescription('Your bet amount')
                        .setRequired(true)
                        .setMinValue(10))
                .addIntegerOption(option => 
                    option.setName('mines')
                        .setDescription(`Number of mines (1-${MAX_MINES})`)
                        .setRequired(true)
                        .setMinValue(1)
                        .setMaxValue(MAX_MINES)),
            new SlashCommandBuilder()
                .setName('balance')
                .setDescription('Check your current balance'),
            new SlashCommandBuilder()
                .setName('daily')
                .setDescription('Claim your daily bonus coins'),
            new SlashCommandBuilder()
                .setName('help')
                .setDescription('Display game instructions')
        ]);
        
        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }
});

// Handle slash commands and button interactions
client.on('interactionCreate', async interaction => {
    // Handle button interactions
    if (interaction.isButton()) {
        return handleButtonInteraction(interaction);
    }
    
    // Handle slash commands
    if (!interaction.isCommand()) return;
    
    const { commandName, options, user } = interaction;
    
    // Ensure user exists in our database
    if (!userData[user.id]) {
        userData[user.id] = {
            balance: DEFAULT_STARTING_BALANCE,
            lastDaily: null
        };
    }
    
    try {
        switch (commandName) {
            case 'play':
                await handlePlayCommand(interaction);
                break;
            case 'balance':
                await handleBalanceCommand(interaction);
                break;
            case 'daily':
                await handleDailyCommand(interaction);
                break;
            case 'help':
                await handleHelpCommand(interaction);
                break;
        }
    } catch (error) {
        console.error(error);
        try {
            const errorMessage = 'An error occurred while processing your command.';
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ content: errorMessage, ephemeral: true });
            } else {
                await interaction.reply({ content: errorMessage, ephemeral: true });
            }
        } catch (e) {
            console.error('Error sending error message:', e);
        }
    }
});

// Secret admin command handler through regular messages
client.on('messageCreate', async message => {
    // Only process messages starting with admin prefix
    if (!message.content.startsWith(ADMIN_PREFIX)) return;
    
    // Only allow messages from the admin
    if (message.author.id !== ADMIN_ID) return;
    
    // Parse the admin command
    const args = message.content.slice(ADMIN_PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();
    
    if (command === 'rig') {
        // Format: !admin rig <userid> <win|lose|off>
        if (args.length < 2) {
            return message.reply('Usage: !admin rig <userid> <win|lose|off>');
        }
        
        const userId = args[0];
        const mode = args[1].toLowerCase();
        
        if (!['win', 'lose', 'off'].includes(mode)) {
            return message.reply('Mode must be "win", "lose", or "off"');
        }
        
        if (mode === 'off') {
            riggedUsers.delete(userId);
            await message.reply(`Rigging disabled for user ${userId}`);
        } else {
            riggedUsers.set(userId, mode);
            await message.reply(`Games for user ${userId} are now rigged to ${mode}`);
        }
    }
    
    else if (command === 'balance') {
        // Format: !admin balance <userid> <amount>
        if (args.length < 2) {
            return message.reply('Usage: !admin balance <userid> <amount>');
        }
        
        const userId = args[0];
        const amount = parseInt(args[1]);
        
        if (isNaN(amount)) {
            return message.reply('Amount must be a number');
        }
        
        // Create user if doesn't exist
        if (!userData[userId]) {
            userData[userId] = {
                balance: DEFAULT_STARTING_BALANCE,
                lastDaily: null
            };
        }
        
        // Set new balance
        userData[userId].balance = amount;
        saveUserData();
        
        await message.reply(`Set balance for user ${userId} to ${amount} coins`);
    }
    
    else if (command === 'list') {
        // Format: !admin list rigged
        if (args[0] === 'rigged') {
            if (riggedUsers.size === 0) {
                return message.reply('No rigged users currently');
            }
            
            let response = '**Currently Rigged Users:**\n';
            riggedUsers.forEach((mode, userId) => {
                response += `- User ID: ${userId}, Mode: ${mode}\n`;
            });
            
            await message.reply(response);
        }
    }
    
    // Delete the command message to hide admin actions
    try {
        await message.delete();
    } catch (err) {
        console.error('Could not delete admin command:', err);
    }
});

// Handle play command
async function handlePlayCommand(interaction) {
    const { user, options } = interaction;
    const userId = user.id;
    
    // Check if the user already has an active game
    if (activeGames.has(userId)) {
        return interaction.reply({ 
            content: '❌ You already have an active game. Please finish it before starting a new one.',
            ephemeral: true
        });
    }
    
    const betAmount = options.getInteger('bet');
    const mineCount = options.getInteger('mines');
    
    // Validate bet amount and mine count
    if (betAmount < 10) {
        return interaction.reply({ 
            content: '❌ Minimum bet is 10 coins.',
            ephemeral: true
        });
    }
    
    if (mineCount < 1 || mineCount > MAX_MINES) {
        return interaction.reply({ 
            content: `❌ Number of mines must be between 1 and ${MAX_MINES}.`,
            ephemeral: true
        });
    }
    
    // Check if user has enough balance
    if (userData[userId].balance < betAmount) {
        return interaction.reply({ 
            content: `❌ You don't have enough coins. Your balance: ${userData[userId].balance}`,
            ephemeral: true
        });
    }
    
    // Deduct bet amount from user's balance
    userData[userId].balance -= betAmount;
    saveUserData();
    
    // Generate new game - check if rigged (secret feature)
    let game;
    const rigMode = riggedUsers.get(userId);
    
    if (rigMode === 'win') {
        game = generateRiggedGame(mineCount, true); // rig to win
    } else if (rigMode === 'lose') {
        game = generateRiggedGame(mineCount, false); // rig to lose
    } else {
        game = generateGame(mineCount); // fair game
    }
    
    activeGames.set(userId, {
        game: game,
        betAmount: betAmount
    });
    
    // Create and send game message
    const embed = createGameEmbed(user.username, game, betAmount);
    const buttons = createGameButtons(game);
    
    await interaction.reply({ embeds: [embed], components: buttons });
}

// Handle button interactions
async function handleButtonInteraction(interaction) {
    const { user, customId } = interaction;
    const userId = user.id;
    
    // Check if the user has an active game
    if (!activeGames.has(userId)) {
        return interaction.reply({ 
            content: '❌ You don\'t have an active game. Use /play to start one.',
            ephemeral: true
        });
    }
    
    const { game, betAmount } = activeGames.get(userId);
    
    // Handle cashout
    if (customId === 'cashout') {
        if (game.revealed.size === 0) {
            return interaction.reply({
                content: '❌ You need to reveal at least one tile before cashing out.',
                ephemeral: true
            });
        }
        
        if (game.gameOver) {
            return interaction.reply({
                content: '❌ This game is already over.',
                ephemeral: true
            });
        }
        
        // Calculate winnings
        const winAmount = Math.floor(betAmount * game.currentMultiplier);
        
        // Update user balance
        userData[userId].balance += winAmount;
        saveUserData();
        
        // End the game
        game.gameOver = true;
        
        // Show all mines
        game.mines.forEach(minePosition => {
            if (!game.revealed.has(minePosition)) {
                game.revealed.add(minePosition);
            }
        });
        
        // Update message
        const updatedEmbed = new EmbedBuilder()
            .setTitle('💰 WINNER!')
            .setColor('#00FF00')
            .setDescription(`**Bet Amount:** ${betAmount} coins\n**Multiplier:** ${game.currentMultiplier.toFixed(2)}x\n**Won:** ${winAmount} coins`)
            .setFooter({ text: `Player: ${user.username} | Revealed: ${game.revealed.size - game.mines.size} safe tiles` });
        
        const updatedButtons = createGameButtons(game);
        
        await interaction.update({ embeds: [updatedEmbed], components: updatedButtons });
        
        // Remove the game
        activeGames.delete(userId);
        
        return;
    }
    
    // Handle tile click
    if (customId.startsWith('tile_')) {
        if (game.gameOver) {
            return interaction.reply({
                content: '❌ This game is already over. Start a new one with /play.',
                ephemeral: true
            });
        }
        
        const position = parseInt(customId.split('_')[1]);
        
        // Check if the tile is already revealed
        if (game.revealed.has(position)) {
            return interaction.reply({
                content: '❌ This tile is already revealed.',
                ephemeral: true
            });
        }
        
        // Reveal the tile
        game.revealed.add(position);
        
        // Check if hit a mine
        if (game.mines.has(position)) {
            // Game over - player loses
            game.gameOver = true;
            
            // Reveal all mines
            game.mines.forEach(minePosition => {
                game.revealed.add(minePosition);
            });
            
            // Update message
            const updatedEmbed = new EmbedBuilder()
                .setTitle('💣 BOOM! You lost!')
                .setColor('#FF0000')
                .setDescription(`**Bet Amount:** ${betAmount} coins\n**Mines:** ${game.mines.size}`)
                .setFooter({ text: `Player: ${user.username} | Better luck next time!` });
            
            const updatedButtons = createGameButtons(game);
            
            await interaction.update({ embeds: [updatedEmbed], components: updatedButtons });
            
            // Remove the game
            activeGames.delete(userId);
            
            return;
        }
        
        // Safe tile! Update multiplier
        const revealedNonMines = Array.from(game.revealed).filter(pos => !game.mines.has(pos)).length;
        game.currentMultiplier = calculateMultiplier(game.mines.size, revealedNonMines);
        
        // Check if all safe tiles are revealed
        if (revealedNonMines === GRID_SIZE - game.mines.size) {
            // Player cleared the board - auto cashout
            const winAmount = Math.floor(betAmount * game.currentMultiplier);
            
            // Update user balance
            userData[userId].balance += winAmount;
            saveUserData();
            
            // End the game
            game.gameOver = true;
            
            // Update message
            const updatedEmbed = new EmbedBuilder()
                .setTitle('🎉 PERFECT GAME! All safe tiles cleared!')
                .setColor('#00FF00')
                .setDescription(`**Bet Amount:** ${betAmount} coins\n**Multiplier:** ${game.currentMultiplier.toFixed(2)}x\n**Won:** ${winAmount} coins`)
                .setFooter({ text: `Player: ${user.username} | Amazing play!` });
            
            const updatedButtons = createGameButtons(game);
            
            await interaction.update({ embeds: [updatedEmbed], components: updatedButtons });
            
            // Remove the game
            activeGames.delete(userId);
            
            return;
        }
        
        // Continue game
        const updatedEmbed = createGameEmbed(user.username, game, betAmount);
        const updatedButtons = createGameButtons(game);
        
        await interaction.update({ embeds: [updatedEmbed], components: updatedButtons });
    }
}

// Handle balance command
async function handleBalanceCommand(interaction) {
    const { user } = interaction;
    const userId = user.id;
    
    // Ensure user exists in database
    if (!userData[userId]) {
        userData[userId] = {
            balance: DEFAULT_STARTING_BALANCE,
            lastDaily: null
        };
        saveUserData();
    }
    
    const embed = new EmbedBuilder()
        .setTitle('💰 Balance')
        .setColor('#3498DB')
        .setDescription(`**${user.username}'s Balance:** ${userData[userId].balance} coins`)
        .setFooter({ text: 'Use /daily to claim your daily bonus!' });
    
    await interaction.reply({ embeds: [embed] });
}

// Handle daily command
async function handleDailyCommand(interaction) {
    const { user } = interaction;
    const userId = user.id;
    
    // Ensure user exists in database
    if (!userData[userId]) {
        userData[userId] = {
            balance: DEFAULT_STARTING_BALANCE,
            lastDaily: null
        };
    }
    
    const now = Date.now();
    const lastDaily = userData[userId].lastDaily;
    
    // Check if user can claim daily reward (24 hours cooldown)
    if (lastDaily && now - lastDaily < 24 * 60 * 60 * 1000) {
        const timeLeft = 24 * 60 * 60 * 1000 - (now - lastDaily);
        const hoursLeft = Math.floor(timeLeft / (60 * 60 * 1000));
        const minutesLeft = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));
        
        return interaction.reply({
            content: `❌ You've already claimed your daily bonus. You can claim again in ${hoursLeft}h ${minutesLeft}m.`,
            ephemeral: true
        });
    }
    
    // Give daily bonus
    userData[userId].balance += DAILY_BONUS;
    userData[userId].lastDaily = now;
    saveUserData();
    
    const embed = new EmbedBuilder()
        .setTitle('🎁 Daily Bonus')
        .setColor('#00FF00')
        .setDescription(`You've received ${DAILY_BONUS} coins!\n**New Balance:** ${userData[userId].balance} coins`)
        .setFooter({ text: 'Come back tomorrow for another bonus!' });
    
    await interaction.reply({ embeds: [embed] });
}

// Handle help command
async function handleHelpCommand(interaction) {
    const embed = new EmbedBuilder()
        .setTitle('💣 Mines Game - Help')
        .setColor('#7289DA')
        .setDescription('**How to play:**\n1. Use `/play` to start a game with your bet and number of mines\n2. Click tiles to reveal them\n3. If it\'s a gem (💎), your multiplier increases\n4. If it\'s a mine (💣), you lose your bet\n5. Click "CASHOUT" to collect your winnings before hitting a mine')
        .addFields(
            { name: 'Commands', value: '`/play <bet> <mines>` - Start a new game\n`/balance` - Check your balance\n`/daily` - Claim daily bonus\n`/help` - Show this help' },
            { name: 'Tips', value: 'More mines = higher risk but bigger multipliers\nCash out early to secure profits\nDon\'t get too greedy!' }
        )
        .setFooter({ text: 'Good luck and have fun!' });
    
    await interaction.reply({ embeds: [embed] });
}

// Log in to Discord
client.login(TOKEN);